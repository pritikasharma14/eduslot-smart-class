const express = require("express");
const router = express.Router();
const User = require("../models/User");

// Signup
router.post("/signup", async (req, res) => {
  const user = new User(req.body);
  await user.save();
  res.json(user);
});

// Login
router.post("/login", async (req, res) => {
  const { email, password,role } = req.body;

  const user = await User.findOne({ email, password ,role});

  if (!user) {
    return res.status(400).json("Invalid credentials");
  }

  res.json(user);
});

module.exports = router;