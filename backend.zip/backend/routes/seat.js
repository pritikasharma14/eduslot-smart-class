const express = require("express");
const router = express.Router();
const Seat = require("../models/Seat");


// ✅ Get all seats
router.get("/", async (req, res) => {
  try {
    const seats = await Seat.find();
    res.json(seats);
  } catch (err) {
    res.status(500).json("Error fetching seats");
  }
});


// ✅ Book seat
router.post("/book", async (req, res) => {
  try {
    const { seatNumber, userEmail } = req.body;

    // ❗ Check if user already booked
    const alreadyBooked = await Seat.findOne({ bookedBy: userEmail });

    if (alreadyBooked) {
      return res.status(400).json("You already booked a seat");
    }

    // ❗ Check if seat already booked
    const seat = await Seat.findOne({ seatNumber });

    if (seat && seat.isBooked) {
      return res.status(400).json("Seat already booked");
    }

    const newSeat = await Seat.findOneAndUpdate(
      { seatNumber },
      { 
        isBooked: true, 
        bookedBy: userEmail,
        bookedAt: new Date()   // 🔥 advanced feature
      },
      { new: true, upsert: true }
    );

    res.json(newSeat);

  } catch (err) {
    console.log(err);
    res.status(500).json("Booking failed");
  }
});


// 🔁 RESET ALL SEATS (Teacher Feature)
router.delete("/reset", async (req, res) => {
  try {
    await Seat.updateMany(
      {},
      { isBooked: false, bookedBy: null, bookedAt: null }
    );

    res.json("All seats reset successfully");
  } catch (err) {
    res.status(500).json("Reset failed");
  }
});


module.exports = router;