import { useNavigate, useLocation } from "react-router-dom";

export default function Navbar() {
  const navigate = useNavigate();
  const location = useLocation();

  return (
   <div style={{
  position: "fixed",   // 🔥 IMPORTANT
  top: 0,
  left: 0,
  width: "95%",
  display: "flex",
  justifyContent: "space-between",
  padding: "15px 30px",
  background: "#1e293b",
  color: "white",
  zIndex: 1000
}}>

      <h2 onClick={() => navigate("/")} style={{ cursor: "pointer" }}>
        EDUSLOT
      </h2>

      <div>

        {/* ✅ ONLY HOME on LOGIN PAGE */}
        {location.pathname === "/login" ? (
          <button onClick={() => navigate("/")}>🏠 Home</button>
        ) : (
          <>
            <button onClick={() => navigate("/")}>🏠 Home</button>
            <button onClick={() => navigate("/login")}>🔐 Login</button>
          </>
        )}

      </div>
    </div>
  );
}