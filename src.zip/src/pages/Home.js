import { useNavigate } from "react-router-dom";
import "./home.css";
export default function Home() {
  const navigate = useNavigate();

  return (
    <div className="home">
      <h1>EduSlot</h1>
      <h3>Smart Classroom Booking System</h3>

      <button onClick={() => navigate("/login")}>
        Start
      </button>

    </div>
  );
}