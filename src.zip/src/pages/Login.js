import { useState } from "react";
import { useNavigate } from "react-router-dom";
import "./login.css";
import axios from "axios";
import Navbar from "../components/Navbar";

export default function Login() {
  const [role, setRole] = useState("student");
  const [email, setEmail] = useState("");
  const [password, setPassword] = useState("");
  const navigate = useNavigate();

  // 🔐 LOGIN
  const handleLogin = async () => {
    if (!email || !password) {
      alert("Please enter email and password");
      return;
    }

    try {
      const res = await axios.post("http://localhost:5000/api/auth/login", {
        email,
        password,
        role
      });

      const user = res.data;

      // ✅ STORE DATA AFTER RESPONSE
      localStorage.setItem("role", user.role);
      localStorage.setItem("userEmail", user.email);

      if (user.role === "student") {
        navigate("/student");
      } else {
        navigate("/teacher");
      }

    } catch (err) {
      alert("Invalid credentials");
    }
  };

  // 🆕 SIGNUP
  const handleSignup = async () => {
    if (!email || !password) {
      alert("Enter email & password first");
      return;
    }

    try {
      await axios.post("http://localhost:5000/api/auth/signup", {
        email,
        password,
        role
      });

      alert("User registered! Now login.");
    } catch (err) {
      alert("Signup error");
    }
  };

  return (
    <div className="login-container">

      {/* 🧭 Navbar */}
      <Navbar />

      <div className="login-box">
        <h2>SmartSeat Login</h2>

        <input
          type="email"
          placeholder="Enter Email"
          onChange={(e) => setEmail(e.target.value)}
        />

        <input
          type="password"
          placeholder="Enter Password"
          onChange={(e) => setPassword(e.target.value)}
        />

        <select onChange={(e) => setRole(e.target.value)}>
          <option value="student">Student</option>
          <option value="teacher">Teacher</option>
        </select>

        <button onClick={handleLogin}>Login</button>

        <button
          onClick={handleSignup}
          style={{ marginTop: "10px", background: "#22c55e" }}
        >
          Signup
        </button>
      </div>
    </div>
  );
}