import { useEffect, useState, useMemo } from "react";
import axios from "axios";
import "./seat.css";
import Navbar from "../components/Navbar";

export default function SeatBooking() {
  const [selectedSeat, setSelectedSeat] = useState(null);
  const [bookedSeats, setBookedSeats] = useState([]);
  const [mySeat, setMySeat] = useState(null);
  const [loading, setLoading] = useState(true);

  const userEmail = "test@gmail.com";

  // ✅ Stable seats (no warning)
  const seats = useMemo(
    () => Array.from({ length: 25 }, (_, i) => i + 1),
    []
  );

  // 🔥 Load seats
  useEffect(() => {
    fetchSeats();
  }, []);

  // 🤖 Auto logic (NO WARNINGS)
  useEffect(() => {
    const isBookedLocal = (seatNum) => {
      return bookedSeats.some(
        (seat) => seat.seatNumber === seatNum && seat.isBooked
      );
    };

    const myBooked = bookedSeats.find(
      (s) => s.bookedBy === userEmail
    );

    if (myBooked) {
      setMySeat(myBooked.seatNumber);
      setSelectedSeat(null);
    } else {
      const available = seats.find((s) => !isBookedLocal(s));
      if (available) setSelectedSeat(available);
    }
  }, [bookedSeats, seats]);

  const fetchSeats = async () => {
    try {
      const res = await axios.get("http://localhost:5000/api/seat");
      setBookedSeats(res.data);
    } catch (err) {
      console.log("Error fetching seats:", err);
    } finally {
      setLoading(false);
    }
  };

  const handleBook = async () => {
    if (!selectedSeat) return;

    try {
      await axios.post("http://localhost:5000/api/seat/book", {
        seatNumber: selectedSeat,
        userEmail: userEmail
      });

      alert("Seat booked successfully!");
      fetchSeats();
    } catch (err) {
      alert(err.response?.data || "Booking failed");
    }
  };

  // ✅ For UI
  const isBooked = (seatNum) => {
    return bookedSeats.some(
      (seat) => seat.seatNumber === seatNum && seat.isBooked
    );
  };

  return (
    <div className="container">

      {/* 🧭 Navbar */}
      <Navbar />

      {/* 🔥 Title */}
      <h1 style={{ textAlign: "center", marginTop: "20px" }}>
        EDUSLOT
      </h1>

      <h3 style={{ textAlign: "center", color: "#94a3b8" }}>
        Smart Classroom System
      </h3>

      <h2 style={{ textAlign: "center", marginTop: "20px" }}>
        Book Your Seat
      </h2>

      {/* 🤖 AI Suggestion */}
      <p style={{ textAlign: "center" }}>
        AI Suggestion: Best available seat is pre-selected for you 🤖
      </p>

      {/* 🔄 Loading */}
      {loading ? (
        <p style={{ textAlign: "center" }}>Loading seats...</p>
      ) : (
        <>
          {/* 🪑 Grid */}
          <div className="grid">
            {seats.map((seat) => (
              <div
                key={seat}
                onClick={() =>
                  !isBooked(seat) && !mySeat && setSelectedSeat(seat)
                }
                className={`seat 
                  ${selectedSeat === seat ? "selected" : ""} 
                  ${isBooked(seat) ? "booked" : ""}
                `}
              >
                {seat}
              </div>
            ))}
          </div>

          {/* ✅ Button */}
          <div style={{ textAlign: "center", marginTop: "20px" }}>
            <button
              onClick={handleBook}
              disabled={!selectedSeat || mySeat}
            >
              {mySeat ? "Seat Already Booked" : "Confirm Booking"}
            </button>
          </div>

          {/* 🎯 My Seat */}
          {mySeat && (
            <p style={{ textAlign: "center", marginTop: "15px" }}>
              You have already booked Seat <strong>{mySeat}</strong>
            </p>
          )}
        </>
      )}

    </div>
  );
}