import { useNavigate } from "react-router-dom";
import "./dashboard.css";
import Navbar from "../components/Navbar";

export default function StudentDashboard() {
  const navigate = useNavigate();

  return (
    <div className="dashboard">

      {/* 🧭 Navbar */}
      <Navbar />

      {/* 🔥 Title */}
      <h1 style={{ textAlign: "center", marginTop: "20px" }}>
        EDUSLOT - Student Dashboard
      </h1>

      {/* 📌 Welcome */}
      <p style={{ textAlign: "center", color: "#94a3b8" }}>
        Welcome to Smart Classroom Booking System
      </p>

      {/* 🎯 Action Button */}
      <div style={{ textAlign: "center", marginTop: "30px" }}>
        <button onClick={() => navigate("/booking")}>
          🪑 Book Your Seat
        </button>
      </div>

      {/* 🔓 Logout */}
      <div style={{ textAlign: "center", marginTop: "20px" }}>
        <button onClick={() => window.location.href = "/"}>
          Logout
        </button>
      </div>

    </div>
  );
}