import { useEffect, useState } from "react";
import axios from "axios";
import "./dashboard.css";
import Navbar from "../components/Navbar";

export default function TeacherDashboard() {
  const [seats, setSeats] = useState([]);
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    fetchSeats();
  }, []);

  const fetchSeats = async () => {
    try {
      const res = await axios.get("http://localhost:5000/api/seat");
      setSeats(res.data);
    } catch (err) {
      console.log("Error fetching seats:", err);
    } finally {
      setLoading(false);
    }
  };

  const resetSeats = async () => {
    try {
      await axios.delete("http://localhost:5000/api/seat/reset");
      alert("All seats reset!");
      fetchSeats();
    } catch (err) {
      console.log(err);
    }
  };

  const bookedSeats = seats.filter((seat) => seat.isBooked);

  return (
    <div className="dashboard">

      {/* ✅ NAVBAR */}
      <Navbar />

      {/* 🔥 Title */}
      <h1 style={{ textAlign: "center", marginTop: "20px" }}>
        EDUSLOT - Teacher Dashboard
      </h1>

      {/* 📊 STATS */}
      <div style={{ textAlign: "center", marginTop: "10px" }}>
        <p><strong>Total Seats:</strong> 25</p>
        <p><strong>Booked:</strong> {bookedSeats.length}</p>
        <p><strong>Available:</strong> {25 - bookedSeats.length}</p>
      </div>

      <h3 style={{ textAlign: "center" }}>Booked Seats</h3>

      {/* 🔄 Loading */}
      {loading ? (
        <p style={{ textAlign: "center" }}>Loading...</p>
      ) : bookedSeats.length === 0 ? (
        <p style={{ textAlign: "center" }}>No seats booked yet</p>
      ) : (
        <div style={{ marginTop: "20px" }}>
          {bookedSeats.map((seat) => (
            <div
              key={seat._id}
              style={{
                background: "#1e293b",
                padding: "12px",
                margin: "10px auto",
                borderRadius: "10px",
                width: "300px",
                textAlign: "center",
                boxShadow: "0 0 10px rgba(0,0,0,0.3)"
              }}
            >
              <strong>Seat {seat.seatNumber}</strong>
              <br />
              Booked by: {seat.bookedBy}
            </div>
          ))}
        </div>
      )}

      {/* 🔁 RESET BUTTON */}
      <div style={{ textAlign: "center", marginTop: "20px" }}>
        <button onClick={resetSeats}>
          Reset All Seats
        </button>
      </div>

      {/* 🔓 Logout */}
      <div style={{ textAlign: "center", marginTop: "20px" }}>
        <button onClick={() => window.location.href = "/"}>
          Logout
        </button>
      </div>

    </div>
  );
}